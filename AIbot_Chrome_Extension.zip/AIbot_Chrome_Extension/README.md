---
name: React Content Script UI
description: Basic example of using createShadowRootUi with React.
apis:
  - createShadowRootUi
---

```sh
pnpm i
pnpm dev
```
