export const CONTENT_SCRIPT_MATCHES = "<all_urls>";
